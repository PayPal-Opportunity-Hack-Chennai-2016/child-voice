angular.module("childVoiceApp").service("ajaxService",["$q","$http",function(){
    
    this.getDonationCauseList = function(){
        var deferred = this.$q.defer();
        $http.get("/getDonationCauseList").then(
            function(res){
                console.log(res)
                deferred.resolve(res)
            },
            function(err){
                console.error(err)
                deferred.reject(err)
            }
        )
        return deferred.promise
    }
    
    this.addDonationToCause = function(){
        var deferred = this.$q.defer();
        $http.post("/addDonationToCause").then(
            function(res){
                console.log(res)
                deferred.resolve(res)
            },
            function(err){
                console.error(err)
                deferred.reject(err)
            }
        )
        return deferred.promise
        
    }
    
    
}]);